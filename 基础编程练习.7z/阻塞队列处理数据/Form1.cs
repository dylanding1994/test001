﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using sql.Utility;
using EMPT;
using OleDb;

using EMPT.Utility;


namespace 阻塞队列处理数据
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //泛型集合存实例
        private CancellationTokenSource cts;
        Serial serial;


        string accpetdata ;

        BlockQueue queue = new BlockQueue(100);

        OleDb_Info db = new OleDb_Info();
        private void Form1_Load(object sender, EventArgs e)
        {
            cts = new CancellationTokenSource();
            new Task(() => DealData(cts.Token, false)).Start();
        }


        private void DealData(CancellationToken token, bool v)
        {
            while (!token.IsCancellationRequested)
            {

                if (v)
                {
                    if(queue.Count() < 0)
                    {
                        string info = queue.DeleteQueue();
                        Thread.Sleep(5000);
                        //db.Insert(info);
                        this.Invoke(new Action(() =>
                        {
                            textBox2.Text = "处理数据：" + info;
                        }));
                    }
                   
                  
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serial = new Serial("COM2", "9600");
            serial.SerialOpen();
            serial.sp.DataReceived += Sp_DataReceived;

            if(cts != null)
            {
                cts.Cancel();
            }
            cts = new CancellationTokenSource();
            new Task(() => DealData(cts.Token, true)).Start();
            button1.Enabled = false;

        }

        private void Sp_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            // Byte[] buffer = new Byte[port.sp.BytesToRead];

            accpetdata = "";
            try
            {
                if (accpetdata != null)
                {
                    accpetdata = "";
                }
                accpetdata = serial.sp.ReadExisting();
                serial.sp.DiscardInBuffer();
                serial.sp.DiscardOutBuffer();

                if (string.IsNullOrEmpty(accpetdata))
                {
                    return;
                }
                queue.EnterQueue(accpetdata);

                this.Invoke(new Action(() =>
                {
                    textBox1.Text = "接收到数据：" + accpetdata;
                }));

            }
            catch (Exception ex)
            {

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            serial.SerialsClose();
            if (cts != null)
            {
                cts.Cancel();
            }
            cts = new CancellationTokenSource();
            new Task(() => DealData(cts.Token, false)).Start();
            button1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            queue.dataInQueue();
        }
    }
}
