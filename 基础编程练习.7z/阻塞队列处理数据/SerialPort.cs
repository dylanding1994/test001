﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;

namespace sql.Utility
{
    // 串口通信类
    public class Serial
    {
        public SerialPort sp;
        public string portName;

        /// <summary>
        /// 初始化串口
        /// </summary>
        /// <param name="strName">串口号</param>
        /// <param name="strBps">波特率</param>

        public Serial(string strName, string strBps)
        {


            #region 设置串口的参数
            portName = strName;
            int iBaudRate = int.Parse(strBps);



            //设置各“串口设置”
            sp = new SerialPort(strName, iBaudRate, Parity.None, 8, StopBits.One);
            sp.Handshake = Handshake.None;
            sp.ReceivedBytesThreshold = 1;

           
            #endregion
        }

       

        /// <summary>
        /// 打开串口
        /// </summary>
        /// <returns></returns>
        public bool SerialOpen()
        {
            if (sp == null)
            {
                MessageBox.Show(portName + " 串口不存在！");
                return false;
            }
            try
            {
                if (sp.IsOpen == false)
                {
                    sp.Open();
                    return true;
                }
                else
                {
                    MessageBox.Show(portName + " 串口已经被打开，无法重复打开！");

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
               
                return false;
            }
        }

        public bool SerialsClose()
        {
            if (sp == null)
            {
                MessageBox.Show(portName + " 串口不存在！");
                return false;
            }
            try
            {
                if (sp.IsOpen == true)
                {
                    sp.Close();
                    return true;
                }
                else
                {
                    //MessageBox.Show(portName + " 串口已经被关闭，无法重复关闭！");
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
               
                return false;
            }
        }

        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="array"></param>
        /// <returns></returns>
        public bool SerialsWrite(byte[] array)
        {
            if (sp.IsOpen == true)
            {
                try
                {
                    sp.DiscardOutBuffer();//丢弃来自串行驱动程序的传输缓冲区的数据
                    sp.Write(array, 0, array.Length);
                    //  sp.WriteLine();
                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }
            else
            {
                MessageBox.Show(portName + " 串口已经被关闭，无法向串口写入数据！");
                return false;
            }
        }

        /// <summary>
        /// 接收数据
        /// </summary>
        /// <returns></returns>
       

       
    }

    
}

        
    
