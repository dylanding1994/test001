﻿using EMPT.Utility;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMPT
{
    //存储数据  阻塞队列
    public class BlockQueue
    {
        private readonly BlockingCollection<string> _blockingCollecting;
        
        
        public BlockQueue(int size)
        {
           
            _blockingCollecting = new BlockingCollection<string>(size);
        }

        public void EnterQueue(string data)
        {    
            lock(this)
            {
                _blockingCollecting.Add(data);
            }
           
                 
        }

        public string DeleteQueue()
        {
            string data = null;
            lock(this)
            {
                if (!_blockingCollecting.IsAddingCompleted)
                {
                    data = _blockingCollecting.Take();
                }
            }
           return data;
            
        }

        public void dataInQueue()
        {
            lock(this)
            {
                if (_blockingCollecting.Count > 0)
                {
                    Console.WriteLine("队列中有{0}个数据", _blockingCollecting.Count);
                    foreach (string b in _blockingCollecting.GetConsumingEnumerable())
                    {
                        Console.WriteLine("输出队列中 的数据：{0} ", b);
                    }

                }
                else
                {
                    Console.WriteLine("队列中没有数据");

                }
            }

           

        }

        public int Count()
        {
            return _blockingCollecting.Count;
        }
        
        public void Close()
        {
            _blockingCollecting.Dispose();
        }
    }
}
